# Precedence
Q - Learnong Roll Back + Precedence 

The main Algorithm is in Algorithm/Brain.py file

Simulations is in Simulations/*different files are for diffrent environments
